﻿using System;

namespace CursoCSharp.Fundamentos {
    class PrimeiroPrograma {
        public static void Executar() {
            Console.Write("Primeiro ");
            Console.WriteLine("Programa");
            Console.WriteLine("Terminou!");
        }
    }
}
